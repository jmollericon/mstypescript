// Returns the value of a parameter to the console. 
export function returnGreeting (greeting: string) {
    console.log(`The message from namespace Greetings is ${greeting}.`);
}