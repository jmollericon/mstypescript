"use strict";
exports.__esModule = true;
exports.returnGreeting = void 0;
// Returns the value of a parameter to the console. 
function returnGreeting(greeting) {
    console.log("The message from namespace Greetings is " + greeting + ".");
}
exports.returnGreeting = returnGreeting;
